The code of the article "Potential Field Guided Actor-Critic Reinforcement Learning"

requirements:

python>=3.6
tensorflow==1.14.0
gym==0.11.0
