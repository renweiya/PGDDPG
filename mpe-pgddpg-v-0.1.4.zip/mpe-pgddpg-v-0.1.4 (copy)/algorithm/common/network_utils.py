import tensorflow as tf
import tensorflow.contrib.layers as layers


def mlp_model(input, num_outputs, scope, reuse=False, num_units=256, layer_norm=False, alpha=0.01):
    # This model takes as input an observation and returns values of all actions
    with tf.variable_scope(scope, reuse=reuse):
        out = input
        #layer 1
        out = layers.fully_connected(out, num_outputs=num_units, activation_fn=None)
        if layer_norm:
            out = layers.layer_norm(out, center=True, scale=True)
        # nonlinear activation
        out = tf.maximum(alpha * out, out)
        # out = tf.nn.relu(out)
        
        #layer 2
        # #add by laker
        # out = layers.fully_connected(out, num_outputs=num_units, activation_fn=None)
        # if layer_norm:
        #     out = layers.layer_norm(out, center=True, scale=True)
        # out = tf.maximum(alpha * out, out)
        
        #layer 3
        out = layers.fully_connected(out, num_outputs=num_units, activation_fn=None)
        if layer_norm:
            out = layers.layer_norm(out, center=True, scale=True)
        out = tf.maximum(alpha * out, out)
        
        #last layer
        out = layers.fully_connected(out, num_outputs=num_outputs, activation_fn=None)

        return out

        # out = tf.tanh(out)        
        # out = tf.sigmoid(logits)
        # outputs = fully_connected(net, self.action_dim, activation_fn=tf.tanh)#tanh的值域为[-1.0,1.0]
        # scaled_outputs = tf.multiply(outputs, self.action_bound) # Scale output to [-action_bound, action_bound]
                

def plan_model(input, scope, reuse=False):#add by laker
    #plan
    with tf.variable_scope(scope, reuse=reuse):
        APF_potential=-tf.square(tf.norm(input[:,-4:-2],axis=-1))#last last 4th,3th vector

        xxx_norm=tf.nn.l2_normalize(input[:,-2:], dim=1, epsilon=1e-12,name=None)
        yyy_norm=tf.nn.l2_normalize(input[:,-4:-2], dim=1, epsilon=1e-12,name=None)#last 4th,3th vector
        x_multiply_y=tf.multiply(xxx_norm,yyy_norm)#matrix dot product
        vector_value=tf.reduce_sum(x_multiply_y, axis=1)#sum by line
        
        out=tf.multiply(APF_potential,1-vector_value)#matrix dot product
        
        
        return out