# Details

Date : 2020-08-28 15:26:22

Directory /home/user/Versions-MPE-pgddpg-2020-06/mpe-pgddpg-v-0.1.7 (another copy)/algorithm

Total : 18 files,  1539 codes, 765 comments, 460 blanks, all 2764 lines

[summary](results.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [algorithm/__init__.py](/algorithm/__init__.py) | Python | 0 | 0 | 1 | 1 |
| [algorithm/common/__init__.py](/algorithm/common/__init__.py) | Python | 0 | 0 | 1 | 1 |
| [algorithm/common/distributions2.py](/algorithm/common/distributions2.py) | Python | 79 | 17 | 34 | 130 |
| [algorithm/common/network_utils.py](/algorithm/common/network_utils.py) | Python | 24 | 17 | 13 | 54 |
| [algorithm/common/reinforce_utils.py](/algorithm/common/reinforce_utils.py) | Python | 50 | 3 | 6 | 59 |
| [algorithm/common/tf_utils.py](/algorithm/common/tf_utils.py) | Python | 169 | 132 | 61 | 362 |
| [algorithm/misc.py](/algorithm/misc.py) | Python | 150 | 131 | 43 | 324 |
| [algorithm/prioritized_experience_replay_buffer/__init__.py](/algorithm/prioritized_experience_replay_buffer/__init__.py) | Python | 0 | 0 | 1 | 1 |
| [algorithm/prioritized_experience_replay_buffer/priority_queue_buffer.py](/algorithm/prioritized_experience_replay_buffer/priority_queue_buffer.py) | Python | 181 | 53 | 44 | 278 |
| [algorithm/prioritized_experience_replay_buffer/replay_buffer.py](/algorithm/prioritized_experience_replay_buffer/replay_buffer.py) | Python | 148 | 95 | 31 | 274 |
| [algorithm/prioritized_experience_replay_buffer/segment_tree.py](/algorithm/prioritized_experience_replay_buffer/segment_tree.py) | Python | 69 | 62 | 15 | 146 |
| [algorithm/prioritized_experience_replay_buffer/trajectory_replay_buffer.py](/algorithm/prioritized_experience_replay_buffer/trajectory_replay_buffer.py) | Python | 141 | 90 | 31 | 262 |
| [algorithm/prioritized_experience_replay_buffer/utils.py](/algorithm/prioritized_experience_replay_buffer/utils.py) | Python | 55 | 26 | 12 | 93 |
| [algorithm/trainer/__init__.py](/algorithm/trainer/__init__.py) | Python | 48 | 0 | 16 | 64 |
| [algorithm/trainer/ddpg.py](/algorithm/trainer/ddpg.py) | Python | 203 | 62 | 70 | 335 |
| [algorithm/trainer/fixed.py](/algorithm/trainer/fixed.py) | Python | 8 | 6 | 5 | 19 |
| [algorithm/trainer/pgddpg.py](/algorithm/trainer/pgddpg.py) | Python | 203 | 62 | 70 | 335 |
| [algorithm/trainer/random_agent.py](/algorithm/trainer/random_agent.py) | Python | 11 | 9 | 6 | 26 |

[summary](results.md)