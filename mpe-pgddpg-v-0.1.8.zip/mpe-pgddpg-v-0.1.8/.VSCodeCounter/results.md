# Summary

Date : 2020-04-15 16:48:22

Directory /home/laker/GASIL-master-2/algorithm

Total : 20 files,  1822 codes, 791 comments, 533 blanks, all 3146 lines

[details](details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Python | 20 | 1,822 | 791 | 533 | 3,146 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 20 | 1,822 | 791 | 533 | 3,146 |
| common | 5 | 530 | 257 | 213 | 1,000 |
| prioritized_experience_replay_buffer | 6 | 576 | 342 | 134 | 1,052 |
| trainer | 8 | 716 | 192 | 185 | 1,093 |
| trainer/ddpg | 2 | 254 | 80 | 73 | 407 |
| trainer/gasil | 2 | 384 | 106 | 91 | 581 |
| trainer/simple | 3 | 24 | 3 | 9 | 36 |

[details](details.md)