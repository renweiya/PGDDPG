The code of the article "Potential Field Guided Actor-Critic Reinforcement Learning"

requirements:

python>=3.6
tensorflow==1.14.0
gym==0.11.0


Reward settings (which makes a difficult learning problem):

predator: +10 if all predators catch the prey at the same time. (There are no personal rewards)

prey: +0.1 in each step. (live as long as possible)

