# Details

Date : 2020-04-15 16:48:22

Directory /home/laker/GASIL-master-2/algorithm

Total : 20 files,  1822 codes, 791 comments, 533 blanks, all 3146 lines

[summary](results.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [__init__.py](file:///home/laker/GASIL-master-2/algorithm/__init__.py) | Python | 0 | 0 | 1 | 1 |
| [common/__init__.py](file:///home/laker/GASIL-master-2/algorithm/common/__init__.py) | Python | 0 | 0 | 1 | 1 |
| [common/distributions2.py](file:///home/laker/GASIL-master-2/algorithm/common/distributions2.py) | Python | 277 | 47 | 115 | 439 |
| [common/network_utils.py](file:///home/laker/GASIL-master-2/algorithm/common/network_utils.py) | Python | 54 | 55 | 30 | 139 |
| [common/reinforce_utils.py](file:///home/laker/GASIL-master-2/algorithm/common/reinforce_utils.py) | Python | 30 | 23 | 6 | 59 |
| [common/tf_utils.py](file:///home/laker/GASIL-master-2/algorithm/common/tf_utils.py) | Python | 169 | 132 | 61 | 362 |
| [prioritized_experience_replay_buffer/__init__.py](file:///home/laker/GASIL-master-2/algorithm/prioritized_experience_replay_buffer/__init__.py) | Python | 0 | 0 | 1 | 1 |
| [prioritized_experience_replay_buffer/priority_queue_buffer.py](file:///home/laker/GASIL-master-2/algorithm/prioritized_experience_replay_buffer/priority_queue_buffer.py) | Python | 173 | 61 | 44 | 278 |
| [prioritized_experience_replay_buffer/replay_buffer.py](file:///home/laker/GASIL-master-2/algorithm/prioritized_experience_replay_buffer/replay_buffer.py) | Python | 148 | 95 | 31 | 274 |
| [prioritized_experience_replay_buffer/segment_tree.py](file:///home/laker/GASIL-master-2/algorithm/prioritized_experience_replay_buffer/segment_tree.py) | Python | 69 | 62 | 15 | 146 |
| [prioritized_experience_replay_buffer/trajectory_replay_buffer.py](file:///home/laker/GASIL-master-2/algorithm/prioritized_experience_replay_buffer/trajectory_replay_buffer.py) | Python | 136 | 95 | 31 | 262 |
| [prioritized_experience_replay_buffer/utils.py](file:///home/laker/GASIL-master-2/algorithm/prioritized_experience_replay_buffer/utils.py) | Python | 50 | 29 | 12 | 91 |
| [trainer/__init__.py](file:///home/laker/GASIL-master-2/algorithm/trainer/__init__.py) | Python | 54 | 3 | 12 | 69 |
| [trainer/ddpg/__init__.py](file:///home/laker/GASIL-master-2/algorithm/trainer/ddpg/__init__.py) | Python | 0 | 0 | 1 | 1 |
| [trainer/ddpg/maddpg.py](file:///home/laker/GASIL-master-2/algorithm/trainer/ddpg/maddpg.py) | Python | 254 | 80 | 72 | 406 |
| [trainer/gasil/__init__.py](file:///home/laker/GASIL-master-2/algorithm/trainer/gasil/__init__.py) | Python | 0 | 0 | 1 | 1 |
| [trainer/gasil/gasil.py](file:///home/laker/GASIL-master-2/algorithm/trainer/gasil/gasil.py) | Python | 384 | 106 | 90 | 580 |
| [trainer/simple/__init__.py](file:///home/laker/GASIL-master-2/algorithm/trainer/simple/__init__.py) | Python | 0 | 0 | 1 | 1 |
| [trainer/simple/fixed.py](file:///home/laker/GASIL-master-2/algorithm/trainer/simple/fixed.py) | Python | 8 | 0 | 2 | 10 |
| [trainer/simple/random_agent.py](file:///home/laker/GASIL-master-2/algorithm/trainer/simple/random_agent.py) | Python | 16 | 3 | 6 | 25 |

[summary](results.md)